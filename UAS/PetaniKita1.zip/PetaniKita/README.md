Petanikita is a small project
